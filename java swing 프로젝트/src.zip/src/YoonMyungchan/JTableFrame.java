package YoonMyungchan;
import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.sql.*;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;

import java.sql.*;


public class JTableFrame extends JFrame {
	
	Connection con = null;
	PreparedStatement ps = null;
	ResultSet rs = null;
	private JTable table;
	private JScrollPane sc;
	private TableModel data;
	private TableColumnModel price;
	

	JFrame fr = new JFrame();
	JPanel jp = new JPanel();
	public JTableFrame()  {
		
		
		try {
            Class.forName("oracle.jdbc.OracleDriver");
            Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE","aban","1111");
            Statement state = conn.createStatement();
            String query = "select * from brain_pric";
            ResultSet rs = state.executeQuery(query);
            ResultSetMetaData rsmd = rs.getMetaData();
            JTable table = new JTable();
            table.setLocation(0,0);

            DefaultTableModel model = (DefaultTableModel) table.getModel();
            
            int cols = rsmd.getColumnCount();
            String[] colName = new String[cols];
            for(int i = 0; i < cols; i++) {
               colName[i] = rsmd.getColumnName(i+1);
               model.setColumnIdentifiers(colName);
               String type, price;
               while(rs.next()) {
                  type = rs.getString(1);
                  price = rs.getString(2);
                  String[] row = {type, price};
                  model.addRow(row);
               }
            }         
         } catch (Exception e1) {
            e1.printStackTrace();
         }
			
	
		
	
		}
	
	

	public static void main(String[] args) {
		JTableFrame JT = new JTableFrame();
		
		
		
	}
}
 


