package JeongTaeSeong;

import java.awt.*;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;

import javax.swing.*;
import javax.swing.table.*;

public class TableTest2 {
    public  void Table() {
        JFrame frame = new JFrame("Table Test");
        frame.setPreferredSize(new Dimension(700, 400));
        frame.setLocation(500, 50);
        Container contentPane = frame.getContentPane();
        
        String colName[] = {
            "병원명",
            "내용",
            "날짜"
        };
        
        //
        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		Date date = new Date();        
		String dateToStr = dateFormat.format(date);
        //
        
        DefaultTableModel model = new DefaultTableModel(colName, 0) {
        	@Override	//테이블 수정 불가
        	public boolean isCellEditable(int row, int column) {
        		if (column >= 0) {
        			return false;
    			} else {
    				return true;
				}
    		}
        };
        
        JTable table = new JTable(model);
        table.getColumnModel().getColumn(0).setPreferredWidth(80);
        table.getColumnModel().getColumn(1).setPreferredWidth(400);
        table.getColumnModel().getColumn(2).setPreferredWidth(50);
        table.getTableHeader().setResizingAllowed(false);
        table.getTableHeader().setReorderingAllowed(false);
        contentPane.add(new JScrollPane(table), BorderLayout.CENTER);
        JPanel panel = new JPanel();
        JTextField text1 = new JTextField(6);
        JTextField text2 = new JTextField(30);
        JButton button1 = new JButton("게시");
        JButton button2 = new JButton("불러오기");
        panel.add(new JLabel("병원명"));
        panel.add(text1);
        panel.add(new JLabel("내용"));
        panel.add(text2);
        
        panel.add(button1);
        panel.add(button2);
        contentPane.add(panel, BorderLayout.SOUTH);
        button1.addActionListener(new AddActionListener(table, text1, text2, dateToStr));
        button2.addActionListener(new RemoveActionListener(table));
        frame.pack();
        frame.setVisible(true);
    }
}