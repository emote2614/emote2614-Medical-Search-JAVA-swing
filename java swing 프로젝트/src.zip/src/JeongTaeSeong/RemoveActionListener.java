package JeongTaeSeong;
import javax.swing.*;

import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;

import javax.swing.table.*;
public class RemoveActionListener implements ActionListener {
    
	JTable table;
    
    RemoveActionListener(JTable table) {
        this.table = table;
    }
    
    public void actionPerformed(ActionEvent e) {
       
    	try {
			Class.forName("oracle.jdbc.OracleDriver");
			Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@127.0.01:1521:XE","aban","1111");
			Statement state = conn.createStatement();
			String query = "select * from member";
			ResultSet rs = state.executeQuery(query);
			ResultSetMetaData rsmd = rs.getMetaData();
			DefaultTableModel model = (DefaultTableModel) table.getModel();
			
			int cols = rsmd.getColumnCount();
			String[] colName = new String[cols];
			for(int i = 0; i < cols; i++) {
				colName[i] = rsmd.getColumnName(i+1);
				model.setColumnIdentifiers(colName);
				String id, content, date;
				while(rs.next()) {
					id = rs.getString("id");
					content = rs.getString("content");
					date = rs.getString("date");
					String[] row = {id, content, date};
					model.addRow(row);
				}
			}
			
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		
        
        
        
    }
}
