package JeongTaeSeong;

import javax.swing.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;

import javax.swing.table.*;


public class AddActionListener implements ActionListener {
	
	private static final String driver="oracle.jdbc.driver.OracleDriver";
	private static final String url="jdbc:oracle:thin:@//localhost:1521/XE";
	private static final String user="aban";
	private static final String pwd="1111";
	
	
    JTable table;
    JTextField text1,text2;
	String dateToStr;
    LocalDate now = LocalDate.now();
    AddActionListener(JTable table, JTextField text1, JTextField text2, String dateToStr) {
        this.table = table;
        this.text1 = text1;
        this.text2 = text2;
        this.dateToStr = dateToStr;
    }
    public void actionPerformed(ActionEvent e) {
        String arr[] = new String[3];
        arr[0] = text1.getText();
        arr[1] = text2.getText();
        arr[2] = dateToStr;
        DefaultTableModel model = (DefaultTableModel)table.getModel();
        model.addRow(arr);
        
        Connection conn;
		Statement stmt;
		ResultSet rs;
        
        try {
			Class.forName(driver);
			System.out.println("Oracle 드라이버 로딩 성공");
			conn=DriverManager.getConnection(url, user,pwd);
			System.out.println("Connection 생성 성공");
			
			stmt=conn.createStatement();
			System.out.println("Statement 객체 생성 성공");
			
			String query="insert into MEMBER values(\'"+arr[0]+"\',\'"+arr[1]+"\',\'"+dateToStr+"\')";
			System.out.println(query);
			
			stmt.executeUpdate(query);
			String query2="select * from Member";
			System.out.println(query);
			rs=stmt.executeQuery(query2);
			
			while(rs.next()) {
				System.out.println("아이디 >> " +rs.getString(arr[0]));
				System.out.println("내용 >> "+rs.getString(arr[1]));
				System.out.println("날짜 >> "+rs.getString(arr[2]));
				System.out.println();
			}
			rs.close();
			stmt.close();
			conn.close();
			
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
    }
}
