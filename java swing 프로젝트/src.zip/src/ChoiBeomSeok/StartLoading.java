package ChoiBeomSeok;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import KimDongHee.Login;

import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.ImageIcon;
import javax.swing.JProgressBar;
import java.awt.Color;
import java.awt.Font;
import java.awt.Toolkit;

public class StartLoading extends JFrame {

	private JPanel contentPane;
	private JProgressBar progressBar;
	private JLabel Label, Label2;

	public static void main(String[] args) {
		//첫 시작 로딩창 실행
		StartLoading load = new StartLoading();
		load.setVisible(true);
		
		//스레드를 이용한 타이머
		Login log = new Login();
		try {
			for(int i = 0; i <= 100; i++) {
				Thread.sleep(40);
				//i 에 따른 프로그레스바 진행도 출력
				load.progressBar.setValue(i);
				//i가 30, 60 일때 텍스트 변환
				if(i == 30) {
					load.Label.setText("화면 전환중...");
				}else if(i == 60) {
					load.Label.setText("프로그램 실행중...");
				}
					load.Label2.setText(i+"%");
			}
		}catch(Exception e) {
		}
		load.setVisible(false);
		log.setVisible(true);
		load.dispose();
		
		
	}
		

	public StartLoading() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(700, 300, 853, 489);
		contentPane = new GraPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setResizable(false);
		setUndecorated(true);
		setContentPane(contentPane);
		setIconImage(Toolkit.getDefaultToolkit().getImage(MAIN.class.getResource("/Image/IconImg.png")));
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setIcon(new ImageIcon(StartLoading.class.getResource("/Image/Logo_1.png")));
		lblNewLabel.setBounds(12, 10, 829, 469);
		contentPane.add(lblNewLabel);
		
		progressBar = new JProgressBar();
		progressBar.setForeground(Color.ORANGE);
		progressBar.setBounds(12, 389, 829, 31);
		contentPane.add(progressBar);
		
		Label = new JLabel("초기 세팅중...");
		Label.setForeground(Color.WHITE);
		Label.setHorizontalAlignment(SwingConstants.RIGHT);
		Label.setFont(new Font("맑은 고딕", Font.BOLD, 20));
		Label.setBounds(12, 339, 723, 40);
		contentPane.add(Label);
		
		Label2 = new JLabel("0%");
		Label2.setHorizontalAlignment(SwingConstants.LEFT);
		Label2.setFont(new Font("맑은 고딕", Font.BOLD, 22));
		Label2.setForeground(Color.WHITE);
		Label2.setBounds(778, 339, 63, 40);
		contentPane.add(Label2);
	}
}
