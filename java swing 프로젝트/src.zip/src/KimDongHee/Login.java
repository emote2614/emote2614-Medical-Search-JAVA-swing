package KimDongHee;
import java.awt.EventQueue;
import ChoiBeomSeok.*;
import java.awt.Color;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import java.awt.Toolkit;
import javax.swing.border.MatteBorder;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.FileNotFoundException;

import javax.swing.SwingConstants;

public class Login extends JFrame implements ActionListener, MouseListener, MouseMotionListener {

	private JPanel SidePane, TitleBar;
	private JTextField IdTextArea;
	private JPasswordField PwTextArea;
	private JButton SignUpButton;
	private JButton LoginButton;
	private JLabel ExitButton;
	private int tx, ty;
	private JPanel LogoPane_1;
	private JLabel LogoLabel;
	private JLabel PwLabel, IdLabel;
	private String index = "1";
	

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Login() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(Login.class.getResource("/Image/IconImg.png")));
		setTitle("Program");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 301, 502);
		setLocation(700,200);
		setResizable(false);
		setUndecorated(true);
		SidePane = new GraPanel();
		
		SidePane.setBackground(new Color(51, 102, 204));
		SidePane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(SidePane);
		SidePane.setLayout(null);
		
		LogoPane_1 = new JPanel();
		LogoPane_1.setBackground(new Color(0,0,0,0));
		LogoPane_1.setBounds(14, 46, 274, 266);
		SidePane.add(LogoPane_1);
		LogoPane_1.setLayout(null);
		
		LogoLabel = new JLabel("");
		LogoLabel.setHorizontalAlignment(SwingConstants.CENTER);
		LogoLabel.setIcon(new ImageIcon(Login.class.getResource("/Image/Logo_1.png")));
		LogoLabel.setBounds(-19, -25, 293, 466);
		LogoLabel.setBackground(new Color(0,0,0,0));
		LogoPane_1.add(LogoLabel);

		TitleBar = new JPanel();
		TitleBar.addMouseMotionListener(this);
		TitleBar.addMouseListener(this);
		TitleBar.setBackground(new Color(0,0,0,0));
		TitleBar.setBounds(0, 0, 301, 35);
		TitleBar.setBorder(new MatteBorder(0, 0, 2, 0, (Color) Color.WHITE));
		SidePane.add(TitleBar);
		TitleBar.setLayout(null);
		
		IdTextArea = new JTextField(10);
		IdTextArea.setForeground(Color.WHITE);
		IdTextArea.setBackground(new Color(102, 102, 204));
		IdTextArea.setBorder(new MatteBorder(0, 0, 2, 0, (Color) Color.WHITE));
		IdTextArea.setFont(new Font("Dialog", Font.BOLD, 15));
		IdTextArea.setBounds(59, 362, 130, 26);
		SidePane.add(IdTextArea);
		IdTextArea.setColumns(10);
		
		PwTextArea = new JPasswordField(10);
		PwTextArea.setForeground(Color.WHITE);
		PwTextArea.setBackground(new Color(102, 102, 204));
		PwTextArea.setBorder(new MatteBorder(0, 0, 2, 0, (Color) Color.WHITE));
		PwTextArea.setFont(new Font("Dialog", Font.BOLD, 15));
		PwTextArea.setBounds(59, 415, 130, 26);
		SidePane.add(PwTextArea);
		PwTextArea.setColumns(10);
		
		PwLabel = new JLabel("P.W");
		PwLabel.setForeground(Color.WHITE);
		PwLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
		PwLabel.setBounds(18, 420, 38, 16);
		SidePane.add(PwLabel);
		
		IdLabel = new JLabel("I. D");
		IdLabel.setForeground(Color.WHITE);
		IdLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
		IdLabel.setBounds(18, 367, 26, 16);
		SidePane.add(IdLabel);
		
		SignUpButton = new JButton("Sign Up");
		SignUpButton.setBorderPainted(false);
		SignUpButton.setFont(new Font("굴림", Font.BOLD, 12));
		SignUpButton.setFocusable(false);
		SignUpButton.addActionListener(this);
		
		SignUpButton.setBounds(175, 461, 87, 16);
		SidePane.add(SignUpButton);
		
		LoginButton = new JButton("");
		LoginButton.setBorderPainted(false);
		LoginButton.setIcon(new ImageIcon(Login.class.getResource("/Image/Login.png")));
		LoginButton.setFont(new Font("굴림", Font.BOLD, 12));
		LoginButton.setBounds(205, 352, 83, 99);
		SidePane.add(LoginButton);
		LoginButton.setFocusable(false);
		
		
		ExitButton = new JLabel("");
		ExitButton.setBounds(270, 3, 29, 29);
		TitleBar.add(ExitButton);
		ExitButton.addMouseListener(this);
		ExitButton.setFocusable(false);
		ExitButton.setBackground(new Color(0,0,0,0));
		ExitButton.setIcon(new ImageIcon(Login.class.getResource("/Image/close.png")));
		LoginButton.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();
		if(obj == LoginButton) {	// 로그인 버튼
			try {
				Class.forName("oracle.jdbc.OracleDriver");
				Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@127.0.01:1521:XE","aban","1111");
				String sql ="select * from logindata where id= '"+IdTextArea.getText()+"'and password='"+PwTextArea.getText()+"'";
				PreparedStatement ps = conn.prepareStatement(sql);
				ResultSet rs = ps.executeQuery();
				//logindatad에 아이디와 비밀번호의 값이 존재하면 로그인성공 하고 myinfo 테이블에 id속성에 아이디 값을 집어 넣는다. 이유는 메인페이지의 info페이지에 있다.
				//로그인에 성공하면 로그인창이 꺼지고 메인화면인(TEST())로 넘어가게 된다.
				if(rs.next()) {
					JOptionPane.showMessageDialog(SidePane, "로그인을 성공 했습니다","로그인성공",JOptionPane.PLAIN_MESSAGE);
					String insert= "insert into myinfo (id)" + "values('"+IdTextArea.getText()+"')";	
					ps.executeUpdate(insert);
					setVisible(false);
					new MAIN();
				//logindata에 아이디와 비밀번호의 값이 존재 하지 않을 경우	
				}else {
					JOptionPane.showMessageDialog(SidePane, "아이디와 비밀번호를 다시 확인하세요","비밀번호 오류",JOptionPane.ERROR_MESSAGE);
				}
				
			} catch (Exception e2) {
			
			}
		}
		
		if(obj == SignUpButton) {	//회원가입 버튼을 누를시 약관창이 띄어진다.
			try {
				new Terms();
			} catch (FileNotFoundException e1) {
				e1.printStackTrace();
			}
		}
		
	}
	
	

	


	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// x,y 좌표 검색
		tx = e.getX();
	    ty = e.getY();
		
		Object obj = e.getSource();
		if(obj == ExitButton) {
			// 종료를 위한 자바 스윙 확인창
			if(JOptionPane.showConfirmDialog(SidePane, "정말 종료하시겠습니까?", "종료", JOptionPane.YES_NO_OPTION) == 0) {
				System.exit(0);
			}
		}
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseDragged(MouseEvent e) {
		// 구한 x,y 좌표를 사용하여 창 위치 설정할수 있도록 마우스 이벤트 설정
		setLocation(e.getXOnScreen() -tx, e.getYOnScreen() -ty);
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
}
